
import UIKit

//creating classes

//classes are simular to structs
class Dog {
    var name: String
    var breed: String

    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
}
let Poppy = Dog(name: "Poppy", breed: "Poodle")

//class inheritance

//you can create a class ontop of an existing class which inherits all the properties of the original class with new props on top
//old = parent class
//new = child class
class Poodle: Dog {
    init(name: String) {
        super.init(name: name, breed: "Poodle")
    
    }
}
//for safety to use inits in chil classes us super.init

//overiding methods

//child classes can take over parent classes with overiding methods

class Dog0 {
    func makeNoise() {
        print("Woof!")
    }
}
//}
//class Poodle0: Dog {
//    override func makeNoise() {
//        print("Yip!")
//    }
//}
//mine and twostraws code did not work due to swift updates

//Final classes

//final classes cannot be edited by 3rd party
//    final class
//this is to define a final class

//copying objects

//coping structs creats two enetity while coping classes creates one entity
class singer {
    var name1 = "Taylor Swift"
}
var Singer = singer()
print(Singer.name1)
var singerCopy = Singer
singerCopy.name1 = "Ed Sheeran"

print(Singer.name1)

//Deinitialisers

//a peice of code that runs when class is destroyed
class Person {
    var name2 = "John doe"
    init() {
        print("\(name2) is alive!")
    }
    func printGreeting(){
        print("Hello im \(name2)")
    }
    deinit {
        print("\(name2) is no more!")
    }
}
for _ in 1...3 {
    let person = Person()
    Person.printGreeting
}

//mutability

class Singer1 {
    var name4 = "Taylor Swift"
}
let taylor = Singer1()
taylor.name4 = "Ed Sheeran"
print(taylor.name4)
//to stop the chaning from happening you must make the vairable constant var to let

//notes
/*
 classes and structs are simular
 one class can inherit features from another like animals
 final keyword can stop other classes from inheriting from it
 method overiding can let a child class replace a method in its parent class
 when two variables point at the same class instance they point at the same peice of memory and onethe other changes
 classes can have a de initialisersthat runs when an instance of a clss is destroyed
 */
