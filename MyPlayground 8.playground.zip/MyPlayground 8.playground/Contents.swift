import UIKit

//creating your own structs
//structs (also known as structures)
struct Sport {
    var name: String
}
//variables in structs are called properties
var tennis = Sport(name: "tennis")
print(tennis.name)
//the var can be changed
tennis.name = "Lawn Tennis"
// structures can have default values

//Computed Properties

struct Sport0 {
    var name: String
    var isolympicstatus: Bool
    var olympicstatus: String {
        if isolympicstatus {
            return "\(name) is an olympic sport"
        }else{
            return "\(name) is not an olympic sport"
        }
    }
}
/*
//my code
let chessBoxing = Sport(name: "ChessBoxing", isolympicstatus: false)
print(chessBoxing.olympicstatus)
//two straws code
let chessBoxing = Sport(name: "Chessboxing", isolympicstatus: false)
print(chessBoxing.olympicstatus)
//this is invalid either way
 */

//property observers

//property observers let you run code before or after any property changes

struct progress {
    var task: String
    var Amount: Int {
        didSet {
            print("\(task) is now \(Amount)% complete")
        }
    }
}
var Progress = progress(task: "loading data", Amount: 0)
Progress.Amount = 30
Progress.Amount = 80
Progress.Amount = 100

//methods

// functions inside structs are called methods
struct City {
    var population: Int
    func collectTaxes() -> Int {
        return population * 1000
    }
}
//to call struct
let London = City(population: 9_000_000)
London.collectTaxes()
//extra
print("the total ammount of taxation in london is £", London.collectTaxes())

//Mutating methods

//if a struct has a variable property but the instance of that struct was created as a singlr property it can be changed.
struct Person {
    var name: String
    mutating func makeAnonymous() {
        name = "Anonymous"
    }
}
var person = Person(name: "ed")
person.makeAnonymous()
//extra
print("This person is \(person)")

//Properties and methods of strings

let string = "Do or do not, there is no try."
print(string.count)
print(string.hasPrefix("Do"))
print(string.uppercased())
print(string.sorted())
//these are multiple types of print "functions"

//Properties and methods of arrays

var toys = ["woody"]
print(toys.count)
toys.append("Buzz")
toys.firstIndex(of: "Buzz")
print(toys.sorted())
toys.remove(at: 0)
