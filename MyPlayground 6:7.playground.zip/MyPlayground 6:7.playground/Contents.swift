import UIKit

//creating basic closures

let driving = {
    print("I'm driving in my car")
}
driving()

//accepting parameters

let driving0 = { (place: String) in
    print("I'm going to \(place) in my car")
}
driving0("London")

//Returning values

let drivingwithreturn = { (place: String) -> String
    in
    return "I'm going to \(place) in my car"
}
let message = drivingwithreturn("london")
print(message)

//closures as parameters

let driving1 = {
    print("I'm driving in my car")
}
func travel(action: () -> Void){
    print("I'm getting ready to go.")
    action()
    print ("I arrived!")
}
travel (action: driving)

//trailing closure syntax

func travel1(action:() -> Void) {
    print("Im getting ready to go.")
    action()
    print("I Arrived!")
}
travel1 {
    print("I'm driving in my car")

}

//day 7

//closures with parameters

func travel(action: (String) -> Void) {
    print("I'm getting ready to go")
    action("London")
    print("I Arrived!")
}


travel { (place: String) in
    print("I'm going to \(place) in my car")
}

//closusres with return values

func travel(action: (String) -> String) {
    print("I'm getting ready to go.")
    let description = action("London")
    print(description)
    print("I arrived!")
    
}
travel { (place: String) -> String in
    return "Im going to \(place) in my car"
}

//shorthand parameter names

func travel2(action: (String) -> String) {
    print("I'm getting ready to go.")
    let description = action("London")
    print(description)
    print("I arrived!")
    
}
travel2 {
    return "Im going to \($0) in my car"
}

//$number automatic name
//swift knows it needs to return a string from the code above

//closures with multiple parameters

func travel (action: (String, Int) -> String) {
    print("I'm getting ready to go.")
    let description = action("London", 60)
    print(description)
    print("I arrived !")
}
travel {
    "Im going to \($0) at \($1) miles per hour."
}
//can be confusing

//returning closures from functions

func travel() -> (String) -> Void {
    return {
        print("I'm going to \($0)")
    }
}
let result = travel()
result("London")
let result2 = travel() ("london")

//capturing values

func travel3() -> (String) -> Void {
    var counter = 1
    return {
        print("I'm going to \($0)")
    }
}
let result3 = travel()
result3("london")
result3("London")

//Notes
/*
 assign closures to variables and call them later
 closure just like functions can accept parameters and return values
 you can pass functions as parameters
 if the last parameter to your function is a closure you can use a trailing closure syntax
 swift automatically provides sorthand parameter names that go up from zero and start with $ eg $0, $1 although they arent recommended
 if you use external values inside closures they will be captured so swify can refer to them later
 */
