import UIKit

//Consolidation day 1

//variables and constants

//var name = "Tim McGraw"
var name = "Tim McGraw"
//var name = "romeo"
//name = "romeo"
//constants are more widely used by developers
//xcode reccomend let
//var and let name need to be ynique even between them

//Types of data

var name0: String
name0 = "zerotwo"
//type annotations
var code: Int
code = 002
//code = "zerotwo"
//name = 02
var latitude: Double
latitude = 36.166667
var longitude: Double
longitude = -1286.783333
//doubles are more acurate as it holds more digits
//doubles still have limits
//Bool
var stayouttoolate: Bool
stayouttoolate = true
var nothinginbrain: Bool
nothinginbrain = true
var missabeat: Bool
missabeat = true
var missabeat0 = false
var missabeat1: Bool = true
//type annotations are advised as theyre clearer

//operators

//mathimathical operators
var a = 10
a = a + 1
a = a - 1
a = a * a
var b = 10
b += 10
b -= 10
var c = 1.1
var d = 2.2
var e = c + d
var name1 = "hiro"
var name2 = "hana"
var both = name1 + " and " + name2
//% = modulus divide remainder
c > 3
c >= 3
c > 4
c < 4
 var name3 = "osk"
name3 != "oskvald"
stayouttoolate
!stayouttoolate

//string interpolation

var name4 = "zerotwo"
print(name4)
print("hi, \(name4)!!!")

"your name is \(name4), your code is \(code), and you live at \(latitude), \(longitude)."
var age = 25
"Your age is \(age). In \(age) years time you will be \(age * 2)"

//arrays

var evenNumber = [2, 4, 6, 8]
var songs = ["Stand proud", "Robot heart", "Escape"]
// swift counts arrays at zero
songs[0]
songs[1]
songs[2]
type(of: songs)

var songs0: [String]
//songs[0] = "shake it off"

//dictionaries

var person = ["First": "Zero", "Last": "Two", "Birth": "Febuary", "Website": "zerotwo-waifu.com"]
person["First"]
person["Website"]

//conditional code
var action: String
var person0 = "Darling"
if person0 == "Darling" {
    action = "Zerotwo"
}else if person0 == "Hiro"{
    action = "Hiro!!!!!"
}else{
    action = "Baka"
}
//&& = both need to be true
if stayouttoolate && nothinginbrain {
    action = "Not an anime reference"
}
if !stayouttoolate && !nothinginbrain {
    action = "Good your not insane"
}

//Loops
for i in 1...10 {
    print("\(i) times \(i) = \(i * i)")
}
var str = "Fakers gonna"
for _ in 1...5 {
    str += " Fake"
}
print(str)

for song in songs {
    print("My favourite song is \(song)")
}
//loop costnats can have any names
var counter = 0
while true {
    print("counter is now \(counter)")
    counter += 1
    if counter == 556 {
        break
    }
}

//switch cases

let livealbums = 2
switch livealbums {
case 0...1:
    print("You're just staarting out")
case 2...4:
    print("You're a rising star")
case 4...5:
    print("You're world renound!")
default:
    print("Have you done somehting new?")
}

