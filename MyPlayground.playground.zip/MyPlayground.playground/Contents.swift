import UIKit

var str = "hi, it's me hubert"
var age = 12
var day = 0_000_001
var str2 = """
Im learning swift with 100 days of swift \
i can do multi-line comments now \
as well as intergers, strings and vaiables
"""
var str3 = "im \(age) years old"
var str4 = """
This above me is string interpolation \
bacically i can take a pprevious variable and use it again in this text \
also below me, these are constraints and they make it so i cant accidentally change scipt
"""
let youguys = "awesome"
//hi im a comment
/*
 and im a multi line comment
 ha ha
 */
var str5 = "Thanks for checking out my post for day \(day) of my journey. You Guys are \(youguys)"
var num = 1_000_000

