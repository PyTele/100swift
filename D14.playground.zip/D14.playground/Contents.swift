import UIKit

//functions

func favoritealbum(name: String) {
    print("my album is \(name)")
}
// to call function
favoritealbum(name: "Ditf OST")


func printalbumrelease(name: String, year: Int){
    print("\(name) was released in \(year)")
}

printalbumrelease(name: "Ditf OST", year: 2018)

func countlettersinstring(in str: String) {
    print("the string \(str) has \(str.count) letters.")
}
countlettersinstring(in:"Hello")

func albumisditf(name: String) -> Bool {
    if name == "Ditf" {return true}
    if name == "Ditf OST" {return true}
    return false
}
if albumisditf(name: "Ditf") {
    print("Thats from the anime!")
}else{
    print("who made that?")
}
if albumisditf(name: "Escape") {
    print("Thats from the anime!")
}else{
    print("who made that?")
}

//optionals

func gethaterstatus(weather: String) -> String? {
    if weather == "sunny" {
        return nil
    } else {
    return "Hate"
    }
}
var status: String?
status = gethaterstatus(weather: "rainy")
func takehateraction(status: String) {
if status == "Hate" {
    print("Hating")
    }
}
if let haterstatus = gethaterstatus(weather: "Rainy") {
    takehateraction(status: haterstatus)
}

//optional chaining

func albumrelease(year0: Int) -> String? {
    switch year0 {
    case 2006:
        return "Taylor swift"
    case 2008:
        return "Fearless"
    default:
        return nil
    }
}
let album = albumrelease(year0: 2006)?.uppercased()
print("The album is \(String(describing: album))")
let str = "hello world"
print(str.uppercased())

let album0 = albumrelease(year0: 2006) ?? "unknown"
print("The album is \(album0)")

//Enums

enum weathertype {
    case sun
    case cloud
    case rain
    case wind(speed: Int)
    case snow
}

func gethaterstatus0(weather0: weathertype) -> String? {
    switch weather0 {
    case .sun:
        return nil
    case .wind(let speed) where speed < 10:
        return "Meh"
    case .cloud, .wind:
        return "dislike"
    case .rain:
        return "Hate"
    case .snow:
        return "happ"
    }
}
gethaterstatus0(weather0: .cloud)
gethaterstatus0(weather0: .wind(speed: 9001))

//structs

struct person {
    var clothes: String
    var shoes: String
    
    func describe() {
        print("I like wearing \(clothes) with \(shoes)")
    }
}
let zerotwo = person(clothes: "Dresses", shoes: "boots")
let other = person(clothes: "short skirts", shoes: "high heels")

print(zerotwo.clothes)
print(other.shoes)

var zerocopy = zerotwo
zerocopy.shoes = "flip flops"
print(zerotwo)
print(zerocopy)

//classes

class person0 {
    var clothes: String
    var shoes: String
    
    init(clothes: String, shoes: String) {
        self.clothes = clothes
        self.shoes = shoes
    }
}
@objcMembers class singer {
var  name: String
var age: Int
    init(name: String, age: Int){
        self.name = name
        self.age = age
    }
    func sing() {
        print("la la la la ")
    }
}

class Countrysinger: singer {
    override func sing() {
        print("Trucks, guitar and liquor")
    }
}

class heavymetalsinger: singer {
    var noiselevel: Int
        
        init(name: String, age: Int, noiselevel: Int){
            self.noiselevel = noiselevel
            super.init(name: name, age: age)
    }
        override func sing() {
            print("GRRR RARGH RARGH RARRRRGH!")
    }
}


var Taylor = heavymetalsinger(name: "Taylor", age: 25, noiselevel: 9001)
Taylor.name
Taylor.age
Taylor.sing()
//@objc and @objcMembers get data from the system ie ios
