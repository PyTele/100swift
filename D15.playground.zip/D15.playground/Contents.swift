import UIKit

//properties

struct Person {
    var Clothes: String
    var Shoes: String
    func describe() {
        print("I like wearing \(Clothes) with \(Shoes)")
    }
    
}
 let zerotwo = Person(Clothes: "Dresses", Shoes: "boots")
let other = Person(Clothes: "short skirts", Shoes: "high heels")
zerotwo.describe()
other.describe()


struct Person0 {
    var clothes0: String {
    willSet {
        updateUI(msg: "I'm changing from \(clothes0) to \(clothes0)")
    }
        didSet {
            updateUI(msg: "I just changed from \(oldValue) to \(clothes0)")
        }
    }
}
func updateUI(msg: String) {
    print(msg)
}
var Taylor = Person0(clothes0: "T-shirts")
Taylor.clothes0 = "Short skirts"

struct Person1 {
    var age1: Int
    var ageindogyears: Int {
        get {
            return age1 * 7
        }
    }
    
}
var fan = Person1(age1: 25)
print(fan.ageindogyears)

//Static properties and methods

struct Taylorfan {
    static var favouritesong = "Look what you made me do"
    var name: String
    var age: Int
}
let Fan = Taylorfan(name: "James", age: 25)
print(Taylorfan.favouritesong)

//Access control

private var happ = "happ"

//Polymorphism and typecasting

class Album {
    var albname: String
    init(albname: String) {
        self.albname = albname
    }
}
class Studioalbum: Album {
    var Studio: String
    
    init(albname: String, Studio: String) {
        self.Studio = Studio
        super.init(albname: albname)
    }
    
}
class livealbum: Album {
    var Location: String
    init(albname: String, location: String) {
        self.Location = location
        super.init(albname: albname)
    }
    
}
var taylorSwift = Studioalbum(albname: "Taylor Swift", Studio: "The Castles Studios")
var fearless = Studioalbum(albname: "Speak Now", Studio: "Aimeeland Studio")
var iTunesLive = livealbum(albname: "iTunes Live from SoHo", location: "New York")

var allAlbums: [Album] = [taylorSwift, fearless, iTunesLive]

let number = 5
let text = String(number)
print(text)

//closures

let vw = UIView()
UIView.animate(withDuration: 0.5){
    vw.alpha = 0
}
