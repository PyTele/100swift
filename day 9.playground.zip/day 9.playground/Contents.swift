import UIKit

//initialisers

//all structs come with an initialiser by default
struct User {
    var username: String
    init() {
        username = "anonymous"
        print("creating a new user!")
    }
}
var user = User()
user.username = "twostraws"
//initially this code was
//var user = User(user.username = "two straws")

//self

//self points to whaterver part of a struct is being used
struct person {
    var name: String
    init(name: String) {
        print("\(name) was born!")
        self.name = name
    }
}

//lazy properties (like me)

//lazy creates the family tree when first acessed
struct familyTree {
init() {
    print("creating family tree!")
    }
}
struct Person {
    var name: String
   lazy var familytree = familyTree()
    init(name: String) {
        self.name = name
    }
}
var ed = Person(name: "Ed")

//static properties and methods

struct Student {
    static var classSize = 0
    var  name: String
    init(name: String) {
        self.name = name
        Student.classSize += 1
    }
    
}
let eddy = Student(name: "Eddy")
let taylor = Student(name: "Taylor")
print(Student.classSize)

// access control

// access control restricts if a peice of code can use properties and methods
struct Person0 {
private var id: String
//    the keyword private makes the variable only be reached withing the struct or function
init(id: String) {
    self.id = id
    }
    func identify() -> String {
        return "My social security number is \(id)"
    }
}
let edith = Person0(id: "12345")

//notes
/*
 you can use computed properties to calculate values on the fly
 if you want to change a property inside a method yuo must mark it as mutating
 use the self constant to refer to the current instance of a struct inside a method
 the lazy keyword tell swift to create properties only when they are first used
 7 you can share properties and instances of a struct using the static keyword
 acess control restics what  code can use properties and methods
 */
