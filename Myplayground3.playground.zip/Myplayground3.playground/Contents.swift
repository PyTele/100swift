import UIKit

//Arithmetic operators

let firstScore = 12
let secondScore = 4
let total = firstScore + secondScore
let difference = firstScore - secondScore
let product = firstScore * secondScore
let divided = firstScore / secondScore
let remainder = 13 % secondScore
//% = remainder of int ie 13 / 4 = 3 r1

//operator overloading

let meaningOfLife = 42
let doubleMeaningOfLife = 42 + 42
//operators can also add strings together but as swift is a type safe lang you cannot mix them
let fakers = "fakers gonna"
let action = fakers + "fake"
//you can also add arrays together
let firsthalf = ["john", "paul"]
let secondhalf = ["george", "ringo"]
let beatles = firsthalf + secondhalf

//Compound assignment operators

var score = 95
score -= 5
//= on end as they assign result to var using
var quote = "the rain in spain minly falls on the"
quote += "spaniards"
//they also work for strings

//comparison operators

let firstscore1 = 6
let secondscore1 = 4
firstscore1 == secondscore1
//is equal to ==
firstscore1 != secondscore1
// is not equal to !=
firstscore1 < secondscore1
// < larger than
firstscore1 >= secondscore1
// smaller than or equal to >=
//this also works with strings as they have a natural alphabetical order
"taylor" <= "swift"

//conditions

let firstcard = 11
let secondcard = 10
if firstcard + secondcard == 2{
    print("Aces A Lucky!")
}else if firstcard + secondcard == 21 {
    print("Blackjack!")
}else {
    print("Regular cards")
}
//else if is to add a second condition if the first criteria isnt met

//combining conditions

let age1 = 12
let age2 = 21
if age1 > 18 && age2 > 18 {
    print("Both are over 18")
}
// && = and
if age1 > 18 || age2 > 18 {
    print("One of them is over 18")
}
// || = or

//The ternary operator

let firstcard1 = 11
let secondcard1 = 10
print(firstcard1 == secondcard1 ? "cards are the same" : "cards are different")
//colon splits if true and if false in this order "true : false"
//same code using regular condition
if firstcard1 == secondcard1 {
    print("cards are the same")
} else if firstcard1 != secondcard1 {
    print("cards are different")
} else {
    print("unknown")
}

//switch statements

//if you have multiple if else statements
let weather = "sunny"
switch weather {
case "rain":
    print("bring an umbrella")
case "snow":
    print("wrap up warm")
case "sunny":
    print("wear sunscreen")
    fallthrough
/*  fallthrough excicutes the next cases action or makes the next case (if met) excicute the previous ones action as well,
 if non of these actions are met nothing gets continued */
default:
    print("enjoy your day!")
}

//Range operators

//..< = creates ranges upto the final value i.e 1, 2, 3, 4
//while ... creates ranges uto and including the final value i.e 1, 2, 3, 4, 5
let score1 = 83
switch score1 {
case 0..<50:
    print("you failed badly.")
case 50..<85:
    print("you did OK.")
default:
    print("you did great!")
}
7 - 5

