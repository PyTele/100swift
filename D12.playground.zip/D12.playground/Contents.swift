import UIKit

//Handling missing data

//optionals make a varible you dont know nil = nothing
var age: Int? = nil
age = 38

//unwrapping optionals

//optionals dont have counts (number of letters)
var name0: String? = nil
if let unwrapped = name0 {
    print("\(unwrapped.count) letters")
} else {
    print("missing name.")
}
//if name holds a string, that string will be held by unwrapped else the else code will be run

//Unwrapping with guard

//guard let also unwrapps optionals
//after guard let is used the optional still remains useable
func greet(_ name: String?) {
    guard let unwrapped = name else {
        print("You didnt provide a name" )
        return
    }
    print("Hello, \(unwrapped)")
}

//Force unwrapping

//force optionals let you converts optionals to non optionals ie optionals to integer
let Str = "5"
let num = Int(Str)!
//you code will crash if you were wrong
//only force unwrap when you are sure its safe

//Implicitly unwrapped optionals

//iuo might contain a value or they might be nil but unlike regular optionals they dont need to be unwrapped
//to do this you add an ! after your type name ie
let age0: Int! = nil
//you dont need unwrappers to use these
//however if you try to use them and they dont have values your code crashes
//it generally a better option to use regular optionals

//Nil coalescing

//this unwrapps an optional and returns a value if there is one, if the option was nill a default value is used instead
func username(for id: Int) -> String? {
    if id == 2 {
    return "Senpai zerotwo"
    } else {
        return nil
    }
}
let user = username(for: 15) ?? "Anonymous"
//?? is for the default value

//optional chaining

//if you want to access somthing like a.b.c and b is optional just add a ? after it to enable optional chaingin
//if b = nil everything is ignored and swift write nil
//if it has a value it will be unwrapped and excecution will continue
let names = ["John", "Paul", "George", "Ringo"]
let beatle = names.first?.uppercased()

//optional try

//setup
enum passworderror: Error {
    case obvious
}
func checkPassword(_ password: String) throws ->
    Bool{
        if password == "password"{
            throw passworderror.obvious
        }
        return true
}
do {
    try checkPassword("password")
    print("That password is good!")
}catch{
    print("You cant use that password!")
}
//optionla try's
// try? = changes throwing funcs to funcs that return optionals
if let result = try? checkPassword("password"){
    print("Result was \(result)")
}else{
    print("D'oh.")
}
// try! = use if you know for sure just like Nil coalescing otherwise your code will crash
try! checkPassword("sekrit")
print("OK!")

//Failable initializers

let str0 = "5"
let num0 = Int(str0)
//a failable initialiser is an optional that might or might not work
struct person {
    var id: String
    init?(id: String) {
        if id.count == 9 {
            self.id = id
        }else{
            return nil
        }
    }
}

//Typecasting

class animals {}
class Fish: animals {}
class dog: animals {
    func makeNoise(){
        print("Bark!")
    }
}
let pets = [Fish(), dog(), Fish(), dog()]
//swift will check weather each pet is a dog, if it is we can run makeNoise, this is called type casting
for pet in pets {
    if let dog = pet as? dog {
        dog.makeNoise()
    }
}

//Notes

/*
 optionals let us represent the absence of a value with nil
 swift wont let use use optionals without unwrapping them with if let or guard let
 you can froce unwrap optionals but if they return nil the code will crash
 implicitly unwrapped optionals dont have the safety checks of regular optionals thus letting them be more dangerous but can be helpful if you know the value is not going to be nil although they are not advised
 Nil coalescing allows you to unwrap an optional and create a default responce for nil
 type casting can convert one type of object to another
 */
