import UIKit

//writing functions

//reuse code
func printhelp(){
let message = """
welcome to MyApp !
Run this app inside a directory of images and
MyApp will resize them all into thumbnails
"""
print(message)
}

printhelp()

//acepting parameters

print("hello world")

func square1(number: Int){
    print(number * number )
}
square1(number: 8)


func square(number1: Int) -> Int {
    return number1 * number1
}
let result1 = square(number1: 8)
print()


//parameter labels

func square(number: Int) -> Int {
    return number * number
}
let result = square(number1: 8)
func sayhello(to name: String) {
    print("hello, \(name)!")
}
sayhello(to: "Taylor")

//Omitting parameter label

func greet (_person: String){
    print("Hello, \(_person)!")
}
greet(_person: "Taylor")

//  default parameters

func greet2(_person: String, nicely: Bool = true) {
    if nicely == true {
        print("hello, \(_person)!")
    } else {
        print("oh no, its \(_person) again...")
    }
}
greet2(_person: "taylor")
greet2(_person: "taylor", nicely: false)

//vardic functions

//any number of parameters

print("Haters","Gonna", "Hate")
func square(numbers: Int...) {
    for number in numbers {
        print("\(number) squared is \(number * number)")
    }
}
square(numbers: 1, 2, 3, 4, 5)

//writing throwing functions

enum passworderror: Error {
    case obvious
}
func checkpassword(_ password: String)
    throws -> Bool {
        if password == "password" {
            throw passworderror.obvious
        }
        return true
}

//running throwing functions

do{
    try checkpassword("password")
    print("That password is good!")
}catch {
    print("You can't use that password.")
}

//inout parameters

func doubleinplace(number: inout Int){
    number *= 2
}
var myNum = 10
doubleinplace(number: &myNum)

//notes
/*
 fuctions reuse code
 funcs accept paramets
 funcs return values
 different names for external and internal uses for funcs or remove the external name entirely
 parameters can have default values to write less code
 variadic funtions accept zero or more of a specific parameter and swift converts them into an array
 functions can call errors but use try and catch to do so
 */
