import UIKit

//For loops

let count = 1...10
for number in count {
    print("number is \(number)")
}
let albums = ["red", "1989", "reputation"]
for album in albums {
    print("\(album) is on apple music")
}
print("players gonna")
for _ in 1...5 {
    print ("play")
}

//while loops

var number = 1
while number <= 20 {
    print(number)
    number += 1
}
 print("ready or not, here i come!")

//repeat loop

var number1 = 1
repeat {
    print(number1)
    number1 += 1
} while number1 <= 20
print("ready or not, here i come!")

while false {
    print("this is false")
}
repeat{
    print("this is false")
} while false

//Exiting loops

var countdown = 10

while countdown >= 0 {
    print(countdown)
    countdown -= 1
}
// exiting multiple loops

outerloop: for i in 1...10 {
    for j in 1...10 {
    let product = i * j
    print ("\(i) * \(j) is \(product)")
        if product == 50 {
            print("Its a bullseye!")
            break outerloop
        }
    }
}

//skipping loops

for i in 1...10 {
    if i % 2 == 1 {
        continue
    }
    print(i)
}

//infinate loops

var counter = 0
while true {
    print(" ")
    counter += 1
    
    if counter == 273 {
        break
    }
}
