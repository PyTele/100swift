import UIKit

//arrays

let John = "John Lennon"
let Paul = "Paul Mcartney"
let George = "George Harrison"
let Ringo = "ringo Starr"
let beatles = [John, Paul, George, Ringo]
beatles[0]
beatles[1]
beatles[2]
beatles[3]

//sets

let colours = Set(["red", "green", "blue"])
let couluours2 = Set(["red", "green", "blue", "red", "green", "blue"])
//Tuples
var name = (first: "Taylor", Last: "swift")
name.0
name.first
name.1
name.Last

//Arrays vs set vs tuples

let address = (house: 555, street: "taylor swift avenue", city: "Nashville")
//tuples ^
let set = Set(["aardvark", "astronaut", "azalea"])
//Set ^
let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]
//Arrays ^

//Dictionaries

let heights = [
    "Taylor Swift": 1.78,
    "Ed Sheeran": 1.73,
]
heights["Ed Sheeran"]

//Dictionary default value

let faveoriteicecream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]
faveoriteicecream["Paul"]
faveoriteicecream["Charlotte", default: "Unknown"]

//creating empty collections

var teams = [String: String]()
teams["Paul"] = "Red"
var results = [Int]()
var numbers = Set<Int>()
var word = Set<Int>()
var scores = Dictionary<String, Int>()
var results2 = Array<Int>()

//Enums
//Enumerations

let result = "faliure"
let result2 = "failed"
let result3 = "fail"
enum Result {
    case success
    case failure
}
let result4 = Result.failure

//Enum associated values

enum Activity {
    case bored
    case running(desination: String)
    case talking(topic: String)
    case singing(volume: Int)
}
let talking = Activity.talking(topic: "football")

//Enum raw values

enum Planet: Int {
    case mercury = 1
    case venus
    case earth
    case mars
}
let earth = Planet(rawValue: 2)


