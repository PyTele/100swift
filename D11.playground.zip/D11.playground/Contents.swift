import UIKit

//Protocals

//Protocals are a way of describing what properties and methods you must have
protocol Identifiable1 {
    var id: String {get set}
    
}

struct User: Identifiable1 {
    var id: String
}
//to print this id
func displayId (thing: Identifiable1) {
    print("My, I is \(thing.id)")
}

//Protocal inheritance

//unlike with classes you can inherit from multiple protocals at the same time
protocol Payable {
    func calculateWages() -> Int
}
protocol NeedTraining {
    func study()
}
protocol Hasholiday {
    func takeHoliday(days: Int)
}
//to make an inherited protocal do this
protocol Employee: Payable, NeedTraining, Hasholiday {}

//Extensions

//extensions allow you to add methods to existing types allowing you to make them do thing they werent programmed to do
extension Int  {
    func Squared() -> Int {
        return self * self
    }
}
let number =  8
number.Squared()
print(number.Squared())
extension Int {
    var isEven: Bool {
        return self % 2 == 0
    }
}
print(number.isEven)

//protocal extensions

//^ expand an entire protocals properties
let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]
let Beatles = Set(["Paul", "Ringo", "John", "George" ])
extension Collection {
    func Summarize() {
        print("There are \(count) of us:")
        for name in self {
            print(name)
        }
    }
}
//this also make it easier to write functions for both arrays and sets
pythons.Summarize()
Beatles.Summarize()

//Protocol-oriented programming

protocol Idnetifiable {
    var id0: String {get set}
    func identify()
}
extension Identifiable{
    func identify() {
        print("My ID is \(id).")
    }
}
struct User0: Identifiable {
    var id: String
}
let zerotwo = User0(id: "zerotwo")
zerotwo.identify()

//notes
/*
 protocals decide what methods and properties a conforming (a method or property that follows the rules set) type must have.
 you can build protocals ontop of protocals this is called inheritance
 extesions let you ad your own conditions to types like int
 protocal extensions do the same for protocals
 POP is the practice of designing your code or also know on swift as app architecture with protocals
 */
